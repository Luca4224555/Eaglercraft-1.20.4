
package net.pixelcraft;

import net.pixelcraft.performance.*;

public class LiteModMain {
    public static void initLiteMod() {
        System.out.println("[PixelLite] 軽量化Modが有効です！");
        // ここでパッチ適用の処理を呼び出せるように設計
    }
}
