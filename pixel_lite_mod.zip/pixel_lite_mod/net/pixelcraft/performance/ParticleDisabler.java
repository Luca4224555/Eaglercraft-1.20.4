
package net.pixelcraft.performance;

public class ParticleDisabler {
    public static boolean allowParticles = false;
}
