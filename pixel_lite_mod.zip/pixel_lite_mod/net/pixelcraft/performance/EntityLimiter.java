
package net.pixelcraft.performance;

public class EntityLimiter {
    public static boolean shouldRenderEntity(double distance) {
        return distance < 16.0; // 16ブロック以内のエンティティだけ描画
    }
}
