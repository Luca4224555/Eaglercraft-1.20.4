
package net.pixelcraft.performance;

public class ChunkRenderSkipper {
    public static boolean shouldRenderChunk(int x, int z, int playerX, int playerZ) {
        int dx = Math.abs(x - playerX);
        int dz = Math.abs(z - playerZ);
        return dx < 6 && dz < 6; // 6チャンク以内のみ描画
    }
}
